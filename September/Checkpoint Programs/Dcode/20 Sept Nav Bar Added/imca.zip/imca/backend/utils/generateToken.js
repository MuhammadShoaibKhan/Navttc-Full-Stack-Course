const jwt = require('jsonwebtoken')
//create function  for generate token 
//it has 2 parameter one is res which is to send rex to client 
// other si userid which is used encoding
const generateToken =(res,userID)=>{
    //jwt sign fot creating token
    //it has 3 parameter userid and other is string which we have decoding
    //last is expiry date
    const token = jwt.sign({userID},'me nhi bataonga',{
        expiresIn:"30d"
    })
    //send res to cookie toekn using name jwt
    res.cookie("jwt",token,{
        httpOnly:true,
        secure:true,
        sameSite:'strict',
        maxAge:30* 24* 60* 60* 1000

    })
}
//exporting the function 
exports.generateToken = generateToken