import React, { useEffect, useState,useContext } from 'react';
import { parsePath, useNavigate } from 'react-router-dom';
import { Context } from '../App';

function Login() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [login,setLogin] = useContext(Context)

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log('Email:', email, 'Password:', password);
    try {
      
      const res = await fetch("http://localhost:5000/users/login", {
        method: 'POST',
        credentials:"include", 
        body: JSON.stringify({
          email: email,
          password: password,
        }),
        headers: {
          "Content-Type": 'application/json'
        },
      })
      //const resData = await res.json() reason bcz it res.ok  get the value when it convert to json so it does not give ok status
  
      console.log(res);
      if (res.ok) {
        setEmail('')
        setPassword('')
        navigate('/');
      } else {
        console.log("login failed");
  
      }
  
    } catch (err) {
      console.log("login failed");
      
    }
    
  }
  useEffect(() => {
    if (login) {
      navigate('/')
    }
  }, [login])

  //there is we use bootstrap form there form.control is input and form.label is label 
  return (
    <div className="container mt-5" >
      <h2 style={{ color: 'GrayText', marginTop: "10px", marginBottom: "10px", fontSize: "3rem", fontFamily: "serif" }}>Login</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            first className='form-control'
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            className='form-control'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <br />
        <button type="submit" className='btn btn-dark' style={{ textAlign: 'center', justifyContent: "center" }}>login</button>
      </form>
    </div>
  );

}
export default Login;
