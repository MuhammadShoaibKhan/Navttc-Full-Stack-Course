import React, { useState,useContext,useEffect } from 'react';
import { Context } from '../App';
import { useNavigate } from 'react-router-dom';

function Signup() {
    const navigate = useNavigate()
    const [name, setName] = useState('')
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [login,setLogin] = useContext(Context)

    const handleSubmit =async (e) => {
        e.preventDefault();
        console.log('Name:', name, 'Email:', email, 'Password:', password);
        try {
            const res = await  fetch("http://localhost:5000/users/submit",{
                method:'POST',
                credentials:"include",
                body:JSON.stringify({
                  name:name,
                  email:email,
                  password:password,
    
                }),
                headers:{
                  "Content-Type":'application/json'
                },
            })
                
            if (res.ok) {
                setName('')
                setEmail('')
                setPassword('')
                navigate('/');
    
            }else{
                console.log("login failed");
            }             
            
        } catch (err) {
            
        }
       
    } 
    useEffect(() => {
        if (login) {
          navigate('/')
        }
      }, [login])

    return (
        <div className="container mt-5" >
            <h2 style={{ color: 'GrayText', marginTop: "10px", marginBottom: "10px", fontSize: "3rem", fontFamily: "serif" }}>Signup</h2>
            <form onSubmit={handleSubmit}>
                <div className="form-group">
                    <label htmlFor="name">Name:</label>
                    <input
                        type="text"
                        id="email"
                        className='form-control'
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="email">Email:</label>
                    <input
                        type="email"
                        id="email"
                        className='form-control'
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>

                <div className="form-group">
                    <label htmlFor="password">Password:</label>
                    <input
                        type="password"
                        id="password"
                        className='form-control'
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <br />
                <button type="submit" className='btn btn-dark' style={{ textAlign: 'center' }}>Signup</button>
            </form>
        </div>
    );

}

export default Signup;
