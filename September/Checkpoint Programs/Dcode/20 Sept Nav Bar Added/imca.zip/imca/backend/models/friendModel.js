//import mongoose
const mongoose = require('mongoose');
//creating schema
const friendSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    friendliness: {
        type: Number,
        required: true
    }, toxicity: {
        type: Number,
        required: true
    }, loyalty: {
        type: Number,
        required: true
    },
    contact: {
        type: Number,
        required: true
    }
}, {
    timestamps: true
});
//export schema
module.exports = mongoose.model('Friend', friendSchema);
