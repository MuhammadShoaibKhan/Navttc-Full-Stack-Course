// Write a get api using fetch

// we will use fetch in an async function
const  getfunction = async ()=>{

    // initialize a variable for storing a data
    const abc = await fetch('url from backend')

    //now converting the data into json
    const xyz =await xyx.json()

    //now we use the converted res as our well 

}
getfunction()

const getWWhatever = async()=>{
    //here is fetch the data and  store it 
    const res = await fetch('url')
    //here store data converted into json 
    const resData = await res.json()
}
getWWhatever()
const getdata = async ()=>{
    // here is initilize data and store it
    const data = await fetch ('url')
    //here is converted into json
    const resData = await data.json()

}
getdata()

//we will write a delte handler that we will use for fetch for delete
const deleteHandler = async (particularIdTodel)=>{
    // the fetch has two params one is url and other is object in object 
    // we define a  method:"DELETE" bcz we call delte api 
    const xyz = await fetch(`url/${particularIdTodel}`,{
        method:"DELETE"
    })
    // we converting data into json
    const abc = await xyx.json()

}
//The DELETE wil trigered in res to ONCLICK EVENT 
//<button onclick ={()=>deleteHandler(whatever._id)}>delete</button>
 
const deletehandler = async (idtodel)=>{
    // the delte fetch get two params one is url an other is object that was defien a delete method
    const res = await fetch(`Url/${idtodel}`,{
        mathod:"DELETE"
    })
    const resData = await res.json()

}// the delete will trigered in res onClick EVENT
//<button onclock={()=>deletehandler(whatever._id)}>delte</button>
const delteFunction = async(particularIDTodel)=>{
    const delData = await fetch(`url/${particularIDTodel}`,{
        method:"DELETE"
    })
    const resdata = await delData.json()
}
 //the delte will triggred 0nclicK EVENT that was define by button
 //<button onclick={()>delteFunction(whatever._id)}>delte</button>

 const DeleteHandler = async(id)=>{
    const fetchapi = fetch(`url/${id}`,{
        method:"DELETE"
    })
    const delData = await fetchapi.json()
 }
 //here is onclick event that was define by button
// <button onclick={()=>DeleteHandler(whaever._id)} >delte<button/>



///POST

//we will use our post ftech api with in a submit handler 
//which will br TIGGERED  on submit EVENT  in a form
const submitHandle = (e)=>{
    // it was prevent to reload he page
    e.preventDefault()

}

//put or post Fetch Api 
                // we will  use our POST ftech api with submitHandler
                // which will triggered on an onSubmit event in a form
                const submitHandler = async(e) =>{
                    // it's prevevnting  the deafault reload
                    e.preventDefault()
                    // we  will define our req body
                    const body ={
                        // you desired fields
                        // for example
                        name: name
                    }

                    //initializing a varibles for storing the res
                    // the fetch has 2 parms one is url and other is an eq object and here we

                    const xyz = await fetch ('URL', {
                        // are passing method:'POST' bcz we are calling a post api.
                        method:'POST',
                        // we are converting our body into  json bcz server expect json
                        body: JSON.stringify(body),
                        // we aer telling the that we are sending data is Json format
                        headers:{
                            "Content-type" : "application/json",
                        },
                    })
                    //we are converting the initial res into json
                    const abc =await xyz.json()
                     //. now we can use the converted res as our will.

                }
                     // the POST wil be trrigered is res to onSubmit event
                     //<form onSubmit = {handleSubmit}> Submit
                     // form body 
                     //</form>