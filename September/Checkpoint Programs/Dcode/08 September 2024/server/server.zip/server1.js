const express = require('express');
const mongoose = require('mongoose');
const app = express();
const bodyParser = require('body-parser')
const Product = require('./models/userModels.js')
app.use(bodyParser.urlencoded({extended:true}))

app.get('/contact', (req, res) => {
    res.send(`<div class="container">
        <h2>Submit Your Details</h2>
        <form method="post" action="/submit">
            <div  >
                <label for="name">Name:</label>
                <input name="name" placeholder="Enter your Name"  >
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input name="email"  placeholder="Enter your Email"  >
            </div>
            <div class="form-group">
                <label for="contact">Contact Number:</label>
                <input  name="contact" id="contact" placeholder="Enter your Contact Number"  >
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>`);
});

app.post('/submit', (req, res) => {
   console.log(req.body);
});

app.listen(5000, () => {
    console.log('Server is running ');
});
