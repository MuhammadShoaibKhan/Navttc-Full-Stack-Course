import { Link } from 'react-router-dom';
import Container from 'react-bootstrap/Container';
function Ali (){
    return(
        <Container>
       <div className='mt-5'>
        {/* <img src={ali} alt='ali' /> */}
        <h1>Ali Raza</h1>
        <h2>Frontend Developer</h2>
        <p>Contact: 03xxxxxxxxx</p>
       </div>
       </Container>
    )
}
export default Ali;